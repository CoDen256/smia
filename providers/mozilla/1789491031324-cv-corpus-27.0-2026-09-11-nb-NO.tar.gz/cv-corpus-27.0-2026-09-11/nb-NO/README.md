# *Norsk (bokmål)* &mdash; Norwegian Bokmål (`nb-NO`)

This datasheet is for cv-corpus-27.0-2026-09-11 of the Mozilla Common Voice *Scripted Speech* dataset for Norwegian Bokmål [Norsk (bokmål) - `nb-NO`]. The dataset contains 2252 clips representing 2.62 hours of recorded speech (2.35 hours validated) from 68 speakers, recorded from a text corpus of 8,068 sentences.

## Language

### Accents

| Code | Accent | Clips | Speakers |
|---|---|---|---|
| - |  | 1,895 (84.1%) | 19 (27.9%) |

## Demographic information

The dataset includes the following self-declared age and gender distributions. A coverage summary is shown below each table.

### Gender

Self-declared gender information. The table shows clip and speaker counts with percentages. Speakers who did not declare a gender are listed as Unspecified. A dash (-) indicates zero.

| Code | Gender | Clips | Speakers |
|---|---|---|---|
| male_masculine | Male, masculine | 1,341 (59.5%) | 3 (4.4%) |
| female_feminine | Female, feminine | - | - |
| transgender | Transgender | - | - |
| non-binary | Non-binary | - | - |
| do_not_wish_to_say | Prefer not to say | - | - |
| - | Unspecified | 911 (40.5%) | 65 (95.6%) |

*Gender declared: 1,341 of 2,252 clips (59.5%), 3 of 68 speakers (4.4%)*

### Age

Self-declared age information. The table shows clip and speaker counts with percentages. Speakers who did not declare an age are listed as Unspecified. A dash (-) indicates zero.

| Code | Age | Clips | Speakers |
|---|---|---|---|
| teens | Teens | - | - |
| twenties | Twenties | - | - |
| thirties | Thirties | 1,380 (61.3%) | 4 (5.9%) |
| fourties | Fourties | 435 (19.3%) | 2 (2.9%) |
| fifties | Fifties | 36 (1.6%) | 2 (2.9%) |
| sixties | Sixties | - | - |
| seventies | Seventies | - | - |
| eighties | Eighties | - | - |
| nineties | Nineties | - | - |
| - | Unspecified | 401 (17.8%) | 61 (89.7%) |

*Age declared: 1,851 of 2,252 clips (82.2%), 7 of 68 speakers (10.3%)*

## Data splits for modelling

**Clip buckets**

| Bucket | Clips |
|---|---|
| Validated | 2,021 (89.7%) |
| Invalidated | 99 (4.4%) |
| Other | 132 (5.9%) |

**Training splits**

| Split | Clips |
|---|---|
| Train | 1,273 (63.0%) |
| Dev | 416 (20.6%) |
| Test | 331 (16.4%) |

*Training split coverage: 2,020 of 2,021 validated clips (100.0%)*

The dataset contains 2021 validated, 99 invalidated, and 132 unresolved clips. The average clip duration is 4.192 seconds.

## Text corpus

**Validated sentences:** 4,419

| Category | Count |
|---|---|
| Unvalidated sentences | 3,649 |
| Pending sentences | 3,581 |
| Rejected sentences | 68 |
| Reported sentences | 1 |

The corpus contains 8,068 sentences: 4,419 validated and 3,649 unvalidated (3,581 pending review, 68 rejected), with 1 reported for review.

### Sample

There follows a randomly selected sample of five sentences from the corpus.

1. *femtiåtte tusen sju hundre og sekstien*
2. *hvor er jeg*
3. *en seks seks sju åttitre åtte hundre og tjueen*
4. *Holum*
5. *tjuesju tusen åtte hundre og trettito*

### Sources

| Source | Sentences |
|---|---|
| sentence-collector | 3,242 (73.4%) |
| https://www.nb.no/sprakbanken/ressurskatalog/oai-nb-no-sbr-80/  This is a CC0 licensed corpus cleared from newspaper text. The source sentences from a translation corpus is used.  It is released by Språkbanken. | 673 (15.2%) |
| Selvsitering | 278 (6.3%) |
| Self Citation | 71 (1.6%) |
| https://www.nb.no/sprakbanken/ressurskatalog/oai-nb-no-sbr-80/ This is a CC0 licensed corpus cleared from newspaper text. The source sentences from a translation corpus is used.  It is released by Språkbanken. | 49 (1.1%) |
| Other | 106 (2.4%) |

### Text domains

| Code | Domain | Clips | Speakers |
|---|---|---|---|
| general | General | 719 (31.9%) | 35 (51.5%) |
| agriculture_food | Agriculture and Food | 3 (0.1%) | 2 (2.9%) |
| automotive_transport | Automotive and Transport | - | - |
| finance | Finance | 4 (0.2%) | 2 (2.9%) |
| service_retail | Service and Retail | 38 (1.7%) | 13 (19.1%) |
| healthcare | Healthcare | - | - |
| history_law_government | History, Law and Government | 21 (0.9%) | 5 (7.4%) |
| media_entertainment | Media and Entertainment | 17 (0.8%) | 9 (13.2%) |
| nature_environment | Nature and Environment | 37 (1.6%) | 7 (10.3%) |
| news_current_affairs | News and Current Affairs | 32 (1.4%) | 6 (8.8%) |
| technology_robotics | Technology and Robotics | - | - |
| language_fundamentals | Language Fundamentals | 13 (0.6%) | 6 (8.8%) |

### Fields

#### Clips

Each row of a `tsv` file represents a single audio clip, and contains the following information:

- `client_id` - hashed UUID of a given user
- `path` - relative path of the audio file
- `sentence` - the sentence to be read aloud
- `sentence_id` - unique identifier for the sentence
- `sentence_domain` - domain classification(s) of the sentence
- `up_votes` - number of people who said audio matches the text
- `down_votes` - number of people who said audio does not match text
- `age` - age of the speaker[^1]
- `gender` - gender of the speaker[^1]
- `accents` - accents of the speaker[^1]
- `variant` - variant of the language[^1]
- `locale` - locale code of the language
- `segment` - if sentence belongs to a custom dataset segment, it will be listed here

[^1]: For a full list of age, gender, and accent options, see the [demographics spec](https://github.com/common-voice/common-voice/blob/main/web/src/stores/demographics.ts). These will only be reported if the speaker opted in to provide that information.

#### `validated_sentences.tsv`

The `validated_sentences.tsv` file contains one row per validated sentence in the text corpus:

- `sentence_id` - unique identifier for the sentence
- `sentence` - the sentence text
- `variant` - the variant of the language
- `sentence_domain` - the domain(s) the sentence belongs to
- `source` - the source the sentence was collected from
- `is_used` - whether the sentence is still in circulation for recording
- `clips_count` - number of clips recorded for this sentence

#### `unvalidated_sentences.tsv`

The `unvalidated_sentences.tsv` file contains one row per unvalidated sentence in the text corpus:

- `sentence_id` - unique identifier for the sentence
- `sentence` - the sentence text
- `variant` - the variant of the language
- `sentence_domain` - the domain(s) the sentence belongs to
- `source` - the source the sentence was collected from
- `up_votes` - number of upvotes the sentence received
- `down_votes` - number of downvotes the sentence received
- `status` - current status of the sentence (`pending` or `rejected`)

## Get involved

### Community links

- [Common Voice translators on Pontoon](https://pontoon.mozilla.org/nb-NO/common-voice/contributors/)
- [Common Voice Communities](https://github.com/common-voice/common-voice/blob/main/docs/COMMUNITIES.md)

### Discussions

- [Common Voice on Matrix](https://chat.mozilla.org/#/room/#common-voice:mozilla.org)
- [Common Voice on Discourse](https://discourse.mozilla.org/t/about-common-voice-readme-first/17218)
- [Common Voice on Discord](https://discord.gg/9QTj9zwn)
- [Common Voice on Telegram](https://t.me/mozilla_common_voice)

### Contribute

- [Speak](https://commonvoice.mozilla.org/nb-NO/speak)
- [Write](https://commonvoice.mozilla.org/nb-NO/write)
- [Listen](https://commonvoice.mozilla.org/nb-NO/listen)
- [Review](https://commonvoice.mozilla.org/nb-NO/review)

## Licence

This dataset is released under the [Creative Commons Zero (CC-0)](https://creativecommons.org/public-domain/cc0/) licence. By downloading this data you agree to not determine the identity of speakers in the dataset.
